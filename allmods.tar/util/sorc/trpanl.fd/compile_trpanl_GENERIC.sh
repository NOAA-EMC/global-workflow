#!/bin/sh

######################################################################
#
# Build executable : GFS utilities
#
######################################################################

LMOD_EXACT_MATCH=no
source ../../../sorc/machine-setup.sh > /dev/null 2>&1
cwd=`pwd`
echo " "
export target=GENERIC
echo $target


# Load required modules
source ../../modulefiles/gfs_util.${target}
module list

set -x 

mkdir -p ../../exec
make
mv trpanl ../../exec
make clean
