#!/bin/sh
LMOD_EXACT_MATCH=no
source ../../../sorc/machine-setup.sh > /dev/null 2>&1
cwd=`pwd`
echo " "


# Load required modules
export target=GENERIC

echo $target
source ../../modulefiles/gfs_util.${target}
module list

set -x

mkdir -p ../../exec
make -f makefile.$target
make -f makefile.$target clean
mv mkgfsawps ../../exec
