#!/bin/sh

######################################################################
#
# Build executable GFS utility for GFS V15.0.0 
#
######################################################################

LMOD_EXACT_MATCH=no
source ../../sorc/machine-setup.sh > /dev/null 2>&1
cwd=`pwd`

source ../modulefiles/gfs_util.GENERIC
module list 

dirlist="faxmakr faxmakrx fxcompoz gendata overgridid plotvpap ras2bit 
         ras2bity rdbfmsua redsat rsonde rsondplt sixbitb sixbitb2 
         trpanl trpsfcmv trpsfprv upaprep webtitle wndanftf mkgfsawps"
set -x

for dir in $dirlist
do
  cd ${dir}.fd
  echo "PWD: $PWD"
  set +x
  echo " "
  echo " ### ${dir} ### "
  echo " "
  set -x
  ./compile_${dir}_GENERIC.sh
  set +x
  echo " "
  echo " ######################################### "
  echo " "
  cd ..
  echo "BACK TO: $PWD"
done
