#! /usr/bin/env bash
set -eux


cd ufs_utils.fd/sorc

bash -x build_all_ufs_utils.umb.sh   

exit

