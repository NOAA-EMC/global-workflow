#!/bin/sh
set -x
source ../../../machine-setup.sh

wgrib2_ver=2.0.7
start_dir=$PWD

for dirr in copygb2 degrib2 grbindex tocgrib2 tocgrib \
            cnvgrib copygb  grb2index grib2grib tocgrib2super
do
    echo "starting $dirr"
    cd $start_dir/${dirr}.fd
#    cp  ./compile_${dirr}_theia.sh  ./compile_${dirr}_GENERIC.sh
    ./compile_${dirr}_GENERIC.sh |& tee compile_${dirr}_GENERIC.log
    rm $dirr
    echo "ending $dirr"
    cd ..
done

# Install wgrib
echo "starting wgrib"
cd $start_dir/wgrib.cd
#cp ./compile_wgrib_wcoss.sh ./compile_wgrib_GENERIC.sh 
./compile_wgrib_GENERIC.sh |& tee compile_wgrib_GENERIC.log
rm wgrib
echo "ending wgrib"
cd ..

# Install wgrib2
echo "starting wgrib2"
cd $start_dir/wgrib2_v${wgrib2_ver}
#cp ./compile_wgrib2_wcoss.sh ./compile_wgrib2_GENERIC.sh
./compile_wgrib2_GENERIC.sh ${wgrib2_ver} |& tee compile_wgrib2_GENERIC.log
echo "ending wgrib2"
cd ../..

