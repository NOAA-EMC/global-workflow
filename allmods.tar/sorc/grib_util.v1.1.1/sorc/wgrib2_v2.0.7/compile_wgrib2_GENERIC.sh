#!/bin/sh

LMOD_EXACT_MATCH=no

set -x

machine=GENERIC
machine_lc=generic

makefile=makefile_GENERIC
# Load required modules
module use ../../modulefiles
if [ -n "$1" ]; then
    module load build_wgrib2/${machine_lc}/$1
    echo BRANCH A
    read a
else
    module load build_wgrib2/GENERIC      
     echo branch b
     read a
fi
module list

make -f $makefile
make -f $makefile install
make -f $makefile clean
