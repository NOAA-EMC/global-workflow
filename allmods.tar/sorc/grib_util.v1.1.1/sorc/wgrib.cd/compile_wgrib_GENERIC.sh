#!/bin/sh

LMOD_EXACT_MATCH=no
module load prod_util
module load prod_util/1.1.0

machine_lc=${machine,,} # Get lower case
machine-lc=GENERIC
makefile=makefile_wcoss_GENERIC          

# Load required modules
module use ../../modulefiles
module load build_grib_util/GENERIC       
module list

make -f $makefile
make -f $makefile install

