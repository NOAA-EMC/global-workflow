#!/bin/sh

LMOD_EXACT_MATCH=no
machine_lc=theia
machine_lc=ibm

makefile=makefile_wcoss_${machine_lc}

# Load required modules
module use ../../modulefiles
#module load build_grib_util/${machine_lc}
module list
module load build_grib_util/GENERIC      
makefile=makefile_wcoss_GENERIC


make -f $makefile
make -f $makefile install
make -f $makefile clean

