#!/bin/sh

#set -ex
source ../../machine-setup.sh
export dir_modules=`cd ../modulefiles ; pwd`

cd ..
pwd=$(pwd)

build_type=${1:-'PRODUCTION'}
dir_root=${2:-$pwd}

[ -d $dir_root/exec ] || mkdir -p $dir_root/exec

rm -rf $dir_root/build
mkdir -p $dir_root/build
cd $dir_root/build

    module use /usrx/local/dev/modulefiles/

     source $dir_modules/modulefile.ProdGSI.GENERIC

#cmake -DBUILD_UTIL=ON -DCMAKE_BUILD_TYPE=$build_type -DBUILD_CORELIBS=OFF ..
module list
sleep 5

env | grep NETCDF
cmake -DHDF5_LIBRARIES="$HDF5_ROOT/lib/libhdf5.a" -DHDF5_Fortran_HL_LIBRARIES="$HDF5_ROOT/lib/libhdf5_hl.a" -DBUILD_UTIL=ON -DCMAKE_BUILD_TYPE=PRODUCTION -DBUILD_CORELIBS=OFF ..


#make VERBOSE=1 -j 1
make VERBOSE=1 -j 8

exit
